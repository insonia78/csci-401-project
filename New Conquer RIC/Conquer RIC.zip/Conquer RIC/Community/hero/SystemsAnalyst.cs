﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Community
{
   public partial  class SystemsAnalyst : Hero
    {
        public SystemsAnalyst()
        {
            //Init();
        }

        private void Init()
        {
            /*
             * TODO:
             * initialize with custom stats,
             * pictures, and gender.
             */
        }
    }
}