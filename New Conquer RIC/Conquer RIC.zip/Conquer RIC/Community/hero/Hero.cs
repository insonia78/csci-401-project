﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Community
{
    public partial class Hero : Character
    {
        String gender;
        // TODO: 
        // fields, objects and classes to be created.
        // image variable
        // helmet
        // chest
        // legs
        // arms

        public Hero()
        {
            Init();
        }

        private void Init()
        {
            gender = "female";
            // TODO:
            // instantiate fields
        }

        /*
         * TODO:
         * create gets and sets for the body parts for their current equipment.
         */

    }
}